import school.*;//here we use * to import all classes in that package
public class testing_import_package {
    void main(){
        student1 st=new student1("mohan",22,"A");
        st.get();
        teacher te=new teacher("sri", 121, 10000);
        te.get();
    }


}
